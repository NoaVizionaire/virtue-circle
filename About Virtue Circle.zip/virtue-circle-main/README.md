# virtue-circle
Single-Tier Distributed Non-Profit Marketplace
